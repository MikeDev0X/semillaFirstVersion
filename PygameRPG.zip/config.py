WIN_WITH = 1280 #tamaño del display
WIN_HEIGHT = 720 #tamaño del display
TPIXEL = 35
PLAYERPIXEL = 70 #Tamaño predeterminado de pixeles de los personajes

countImage = 0 #contador de imagenes 
#listas de imagenes
DOWNImages = []
RIGHTImages = []
LEFTImages = []
UPImages = []
RUPImages = []
RDOWNImages = []
LUPImages = []
LDOWNImages = []


# EN que capa quieres que el sprite aparezca / sprite jugador position
PLAYER_LAYER = 3 
BLOCK_LAYER = 2
GROUND_LAYER = 1

PLAYER_SPEED = 16
#tamaño default de nuestras imagenes
DEFAULT_IMAGE_SIZE = (70, 70)
RED = (255,0,0) #RGB 
WHITE = (255, 255, 255) #RGB
BLUE = (0,0,255) #RGB
BlACK = (0,0,0) #RGB
#framerate
FPS = 120 #frames per second


Maps=[]



tilemap = [
'BBBBBBBBBBBBBBBBBBBBBBBBBBBBB',
'B...........................B',
'B...........................B',
'B....CCC....................B',
'B...P.......................B',
'B...........................B',
'B...........................B',
'B...........................B',
'B.....CCC...................B',
'B.......C...................B',
'B.......C...................B',
'B...........................B',
'B...........................B',
'B...........................B',
'B...........................B',
'B...........................B',
'B...........................B',
'B...........................B',
'BBBBBBBBBBBBBBBBBBBBBBBBBBBBB',
]