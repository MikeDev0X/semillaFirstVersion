import pygame
from config import * #importas todo de la clase 
import math
import random

#lista de down images 
for i in range(1,4):
	name = "assets_test/MainCharacter/DOWN"+str(i)+".png"
	DOWNImages.append(pygame.image.load(name))
#lista left images
	name = "assets_test/MainCharacter/LEFT"+str(i)+".png"
	LEFTImages.append(pygame.image.load(name))

	name = "assets_test/MainCharacter/RIGHT"+str(i)+".png"
	RIGHTImages.append(pygame.image.load(name))
#lista up images	
	name = "assets_test/MainCharacter/UP"+str(i)+".png"
	UPImages.append(pygame.image.load(name))
#lista RUP images
	name = "assets_test/MainCharacter/RUP"+str(i)+".png"
	RUPImages.append(pygame.image.load(name))
#lista RDOWN images
	name = "assets_test/MainCharacter/RDOWN"+str(i)+".png"
	RDOWNImages.append(pygame.image.load(name))
#lista LUP images
	name = "assets_test/MainCharacter/LUP"+str(i)+".png"
	LUPImages.append(pygame.image.load(name))
#lista LDOWN images
	name = "assets_test/MainCharacter/LDOWN"+str(i)+".png"
	LDOWNImages.append(pygame.image.load(name))

###MAPAS
Mapa1_magenta=pygame.image.load('assets_test/mapas/mapa1_magenta.png')
Mapa1_magentaResized=pygame.transform.scale(Mapa1_magenta,(WIN_WITH,WIN_HEIGHT))
Maps.append(Mapa1_magentaResized)


class Player(pygame.sprite.Sprite):
	def __init__(self,game,x,y):

		self.game = game
		self._layer = PLAYER_LAYER
		self.groups = self.game.all_sprites
		pygame.sprite.Sprite.__init__(self, self.groups)
    
		self.x = x * PLAYERPIXEL
		self.y = y * PLAYERPIXEL
		self.width = PLAYERPIXEL
		self.height = PLAYERPIXEL
		self.left = False
		self.right = False
		self.up = False 
		self.down = False
		self.LDOWN = False
		self.LUP = False
		self.RDOWN = False
		self.RUP = False
		self.standing = True
		self.hitbox = (self.x + 17, self.y+11, 29,52)
    #self.hitbox = (self.x + 70, self.y+11)
#estas son variables temporales que almacenan el cambio de movimientos dentro del ciclo
		self.x_change = 0
		self.y_change = 0

		self.facing = 'down'
		self.animation_loop = 1
		 #posicion predeterminada de nuestro personaje

		image_to_load = pygame.image.load('assets_test/MainCharacter/DOWN1.png').convert()

		self.image = pygame.Surface([self.width, self.height]) 
		self.image.set_colorkey(WHITE)
		image = pygame.transform.scale(image_to_load, DEFAULT_IMAGE_SIZE)
		# creamos un rectangulo como la imagen de nuestro jugador
		
		self.image.blit(image, (0,0))
		#what it looks like

    

		self.rect = self.image.get_rect()# donde esta posisionado / hitbox / se hace del mismo tamaño que la imagen anteriormente definida
		self.rect.x = self.x
		self.rect.y = self.y
		#funcion actualizar movimiento
	def update(self):
		self.movement()
		self.animation()
		self.rect.x += self.x_change
		self.rect.y += self.y_change
		#funcion de movimiento de personaje
		self.x_change = 0
		self.y_change = 0
		
	def movement(self):
		keys = pygame.key.get_pressed()
		if keys[pygame.K_w] and keys[pygame.K_d]:
				self.standing = False
				self.facing = 'rup'
				self.y_change -= PLAYER_SPEED
				self.x_change += PLAYER_SPEED
		elif keys[pygame.K_s] and keys[pygame.K_d]:
				self.standing = False
				self.facing = 'rdown'
				self.y_change += PLAYER_SPEED
				self.x_change += PLAYER_SPEED
		elif keys[pygame.K_w] and keys[pygame.K_a]:
				self.standing = False
				self.facing = 'lup'
				self.y_change -= PLAYER_SPEED
				self.x_change -= PLAYER_SPEED
		elif keys[pygame.K_s] and keys[pygame.K_a]:
				self.standing = False
				self.facing = 'ldown'	
				self.y_change += PLAYER_SPEED
				self.x_change -= PLAYER_SPEED
		elif keys[pygame.K_a]:
				self.facing = 'left'
				self.standing = False
				self.x_change -= PLAYER_SPEED
		elif keys[pygame.K_d]:
				self.facing = 'right'
				self.standing = False
				self.x_change += PLAYER_SPEED
		elif keys[pygame.K_w]:
				self.facing = 'up'
				self.standing = False
				self.y_change -= PLAYER_SPEED
		elif keys[pygame.K_s]:
				self.facing = 'down'
				self.standing = False
				self.y_change += PLAYER_SPEED
		else:
				self.standing = True
				countImage = 0
		#Player.draw(self,screen)

	def animation(self): #--------------------------------------------------------------------------------funcion donde dibujamos a nuestro personaje
				#lista de down images  image = pygame.transform.scale(image_to_load, DEFAULT_IMAGE_SIZE)
    
          if self.facing == "down":
              if self.standing:
                  self.image  = DOWNImages[0]
                  self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              else:
                  self.image = DOWNImages[math.floor(self.animation_loop)]
                  self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
                  self.animation_loop += 0.1
                  if self.animation_loop >= 3:
                      self.animation_loop = 1
#========================fin
          elif self.facing == "up":
            if self.standing:
              self.image  = UPImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = UPImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                  self.animation_loop = 1
    #=========================fin
          elif self.facing == "left":
            if self.standing:
              self.image = LEFTImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = LEFTImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                self.animation_loop = 1
    #=========================fin
          elif self.facing == "right":
            if self.standing:
              self.image = RIGHTImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = RIGHTImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                self.animation_loop = 1
    #==========================fin
          elif self.facing == "rup":
            if self.standing:
              self.image  = RUPImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = RUPImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                self.animation_loop = 1
    #========================fin
          elif self.facing == "rdown":
            if self.standing:
              self.image  = RDOWNImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = RDOWNImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                  self.animation_loop = 1
    #=========================fin
          elif self.facing == "lup":
            if self.standing:
              self.image = LUPImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = LUPImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                self.animation_loop = 1
    #=========================fin
          elif self.facing == "ldown":
            if self.standing:
              self.image = LDOWNImages[0]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
            else:
              self.image = LDOWNImages[math.floor(self.animation_loop)]
              self.image = pygame.transform.scale(self.image, DEFAULT_IMAGE_SIZE)
              self.animation_loop += 0.1
              if self.animation_loop >= 3:
                self.animation_loop = 1
						
    										

class Block(pygame.sprite.Sprite):
	def __init__(self,game,x,y):
		self.game = game
		self._layer = BLOCK_LAYER
		self.groups = self.game.all_sprites, self.game.blocks
		pygame.sprite.Sprite.__init__(self, self.groups)

		self.x = x * TPIXEL
		self.y = y * TPIXEL
		self.width = TPIXEL
		self.height = TPIXEL
		#todo objeto en la pantalla necesita una imagen

		self.image = pygame.Surface([self.width, self.height])
		#todo objeto en la pantallla se pinta de azul
		self.image.fill(BLUE)
 		#se contornea maás chil de gobierno
		self.rect = self.image.get_rect()
		self.rect.y = self.y
		self.rect.x = self.x


class BackGround(pygame.sprite.Sprite):
  def __init__ (self,game,x,y):
    self.game = game
    self._layer = GROUND_LAYER
    self.groups = self.game.all_sprites
    pygame.sprite.Sprite.__init__(self, self.groups)
    self.x = x * TPIXEL
    self.y = y * TPIXEL
    self.width = TPIXEL
    self.height = TPIXEL

    #self.image = pygame.Surface([self.width, self.height])
    self.image = Maps[game.level-1]
    
    self.rect = self.image.get_rect()
    self.rect.y = self.y
    self.rect.x = self.x
