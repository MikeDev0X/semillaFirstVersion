#18/10/2021--19/10/2021--20/10/2021
#Alejandro Hidalgo Badillo A01423412
#Miguel Jiménez Padilla A01423189
#Marco Antonio Gardida Cortés A01423221
#Jorge E. Turner Escalante A01423182
#Camila Turner Escalante A01423579
#Antonio Noguerón Bárcenas A01423759
import pygame
from sprites import *
from config import *
import sys


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((1280,720))
        #self.screen = pygame.display.set_mode((WIN_WITH, WIN_HEIGHT))
        #definimos nuestra pantalla
        self.clock = pygame.time.Clock(
            )  #permite establecer la velocidad de fotogramas de nuestro juego, es la cantidad de veces que el juego se     actualiza por segundo
        self.font = pygame.font.Font('fonts/SpaceMono-Regular.ttf', 32)
        self.running = True
        self.level=1
        
        #self.enemy_spritesheet = Spritesheet('enemy.png')



    def createTilemap(self):
              #y si ya nos salimos del hackathon? no
                    BackGround(self,0,0)

                    for i, row in enumerate(tilemap):
                        print(i, row)
                        for j, column in enumerate(row):
                            #print(j,column)
                            if column == "C":
                              Block(self,j,i)
                              
                            if column == "P":
                              Player(self,j,i)
                    

    def new(self):

                    #self.createTilemap()

                    # Inicia un nuevo juego

                    # util para saber si el jugador a muerto o si ha decidido abandonar el juego
                    self.all_sprites = pygame.sprite.LayeredUpdates() 
                    #contiene todos los sprites del juego
                    self.blocks = pygame.sprite.LayeredUpdates() 
                    ## contiene las paredes
                    self.enemies = pygame.sprite.LayeredUpdates() 
                    # contiene todos los enemigos de nuestro juego
                    self.attacks = pygame.sprite.LayeredUpdates()  
                    self.createTilemap()
                    #self.player = Player(self, 1, 2)  
                    #la clase de nuestro jugador / 1 y 2 es la posicion de aparicion en X/Y    
                    
                    
                
    def update(self):
        self.all_sprites.update()  # llama a updates que esta en sprites

    def events(self):
        #events loop
        for event in pygame.event.get():
            self.playing = False
            self.running = False

    def draw(self):

        self.screen.fill(WHITE)
        self.all_sprites.draw(self.screen)
        self.clock.tick(FPS)  # actualizamos 60 veces por segundo
        pygame.display.update()

    def main(self):
        while True:
            self.events()
            self.update()
            self.draw()
        self.running = False

    def game_over(self):
        pass

    def intro_screen(self):
        pass


def main():
  myGame = Game()
  myGame.intro_screen()
  myGame.new()

  while myGame.running:
      myGame.main()
      myGame.game_over()

  pygame.quit()
  #sys.exit()

if __name__ == "__main__":
  main()